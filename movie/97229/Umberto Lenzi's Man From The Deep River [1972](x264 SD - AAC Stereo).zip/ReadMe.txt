

****************************************************

【电影原名】 The Man from the Deep River
【中文译名】 来自深河的男人
【字幕格式】 Subrip（.srt） 
【字幕語言】 中文简体/英文
【字幕来源】 转载于慢慢游论坛（https://mmy.la/forum.php?mod=viewthread&tid=102742&highlight=%E6%9D%A5%E8%87%AA%E6%B7%B1%E6%B2%B3%E7%9A%84%E7%94%B7%E4%BA%BA）
【匹配版本】 Umberto Lenzi's Man From The Deep River [1972](x264 SD - AAC Stereo)
【匹配时长】 1:32:53
【匹配帧率】 23.969fps
【字幕制作】 这是安菲尔德
【编辑时间】 2021-3-27

****************************************************

本字幕仅供学习交流，严禁用于商业用途
否则因此产生的一切后果将由你自行承担